import { CoreError } from './errors.mjs';
import { parseStrictJson } from './json.mjs';

export const ENDPOINT_PROFILES = Object.freeze({
  openai_api: Object.freeze({ origin: 'https://api.openai.com', basePath: '/v1', chatPath: '/chat/completions', tokenParameter: 'max_completion_tokens', jsonObject: true, catalog: true }),
  openrouter: Object.freeze({ origin: 'https://openrouter.ai', basePath: '/api/v1', chatPath: '/chat/completions', tokenParameter: 'max_completion_tokens', jsonObject: true, catalog: true }),
  boxapi_ai_v1: Object.freeze({ origin: 'https://ai.boxapi.ir', basePath: '/ai/v1', chatPath: '/chat/completions', tokenParameter: 'max_tokens', jsonObject: false, catalog: false }),
  boxapi_api_v1: Object.freeze({ origin: 'https://ai.boxapi.ir', basePath: '/api/v1', chatPath: '/chat/completions', tokenParameter: 'max_tokens', jsonObject: false, catalog: false }),
  liara_readonly: Object.freeze({ origin: 'https://api.liara.ir', basePath: '/', chatPath: '', tokenParameter: '', jsonObject: false, catalog: false }),
});

async function readBoundedBody(response, maxResponseBytes) {
  if (response.body?.getReader) {
    const reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > maxResponseBytes) {
          await reader.cancel().catch(() => {});
          throw new CoreError('RESPONSE_TOO_LARGE', 'protocol', 'unknown', { httpStatus: response.status, responseBytes: size });
        }
        chunks.push(Buffer.from(value));
      }
      return Buffer.concat(chunks, size);
    } finally { reader.releaseLock(); }
  }
  const text = typeof response.text === 'function' ? await response.text() :
    typeof response.json === 'function' ? JSON.stringify(await response.json()) : null;
  if (typeof text !== 'string') throw new CoreError('INVALID_PROVIDER_RESPONSE', 'protocol', 'unknown', { httpStatus: response.status });
  const bytes = Buffer.from(text, 'utf8');
  if (bytes.length > maxResponseBytes) throw new CoreError('RESPONSE_TOO_LARGE', 'protocol', 'unknown', { httpStatus: response.status, responseBytes: bytes.length });
  return bytes;
}

export async function requestBounded({ fetchImpl, endpoint, requestId, headers, body, timeoutMs, maxResponseBytes }) {
  const permittedHeaders = new Set(['authorization', 'content-type', 'accept', 'http-referer', 'x-title']);
  const requestBytes = body === null || body === undefined ? 0 : Buffer.byteLength(body, 'utf8');
  const liara = endpoint?.profileId === 'liara_readonly';
  if (!endpoint || typeof fetchImpl !== 'function' || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000 ||
      !Number.isInteger(maxResponseBytes) || maxResponseBytes < 1 || maxResponseBytes > (liara ? 16 * 1048576 : 1048576) || requestBytes > 1048576 ||
      Object.keys(headers ?? {}).some(name => !permittedHeaders.has(name.toLowerCase()))) throw new CoreError('INVALID_REQUEST', 'config', 'not_sent');
  const policy = ENDPOINT_PROFILES[endpoint.profileId];
  const liaraPath = liara && /^\/v[12]\/projects\/[A-Za-z0-9][A-Za-z0-9._-]{0,99}(?:\/(?:logs|releases))?$/.test(endpoint.path ?? '');
  const isChat = endpoint.path === `${policy?.basePath}${policy?.chatPath}` && endpoint.method === 'POST';
  const isCatalog = policy?.catalog && endpoint.path === `${policy.basePath}/models` && endpoint.method === 'GET';
  if (!policy || (!isChat && !isCatalog && !(liaraPath && endpoint.method === 'GET' && body == null))) throw new CoreError('INVALID_REQUEST', 'config', 'not_sent');
  if (liara && timeoutMs > 60000) throw new CoreError('INVALID_REQUEST', 'config', 'not_sent');
  const liaraParams = endpoint.query ?? {};
  const pathParts = (endpoint.path ?? '').split('/');
  const route = pathParts.slice(1).join('/');
  const allowedQuery = route.endsWith('/releases') ? new Set(['teamID', 'page', 'count']) :
    route.startsWith('v2/') ? new Set(['teamID', 'start', 'direction', 'last_lines', 'releaseId']) :
      route.endsWith('/logs') ? new Set(['teamID', 'since']) : new Set(['teamID']);
  if (liara && Object.entries(liaraParams).some(([key, value]) => !allowedQuery.has(key) || typeof value !== 'string' || value.length > 160 || /[\r\n]/.test(value))) {
    throw new CoreError('INVALID_REQUEST', 'config', 'not_sent');
  }
  const started = performance.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const target = new URL(endpoint.path, policy.origin);
    for (const [key, value] of Object.entries(liaraParams)) target.searchParams.set(key, value);
    const pathValid = liara ? target.pathname === endpoint.path : target.pathname.startsWith(`${policy.basePath}/`);
    if (target.origin !== policy.origin || !pathValid || (!liara && target.search) || target.hash) {
      throw new CoreError('INVALID_REQUEST', 'preflight', 'not_sent');
    }
    let response;
    try {
      response = await fetchImpl(target.href, {
        method: endpoint.method, redirect: 'error', signal: controller.signal,
        headers: { ...headers, 'x-request-id': /^[A-Za-z0-9._:-]{1,128}$/.test(requestId ?? '') ? requestId : 'starcoach-request' }, ...(body ? { body } : {}),
      });
    } catch {
      throw new CoreError(controller.signal.aborted ? 'TIMEOUT' : 'NETWORK_ERROR', 'transport', 'unknown');
    }
    const advertised = Number(response.headers?.get?.('content-length'));
    if (Number.isFinite(advertised) && advertised > maxResponseBytes && response.ok) throw new CoreError('RESPONSE_TOO_LARGE', 'protocol', 'unknown', { httpStatus: response.status });
    if (!response.ok) {
      let safeProviderCode = null;
      const mayCaptureProviderCode = liara || ['openai_api', 'openrouter', 'boxapi_ai_v1', 'boxapi_api_v1'].includes(endpoint.profileId);
      if (mayCaptureProviderCode && endpoint.captureErrorCode === true && (!Number.isFinite(advertised) || advertised <= maxResponseBytes)) {
        try {
          const errorBytes = await readBoundedBody(response, maxResponseBytes);
          const parsed = parseStrictJson(errorBytes.toString('utf8'), { maxBytes: maxResponseBytes });
          safeProviderCode = parsed?.error?.code;
        } catch { /* status remains available; body is never returned */ }
      }
      const code = response.status >= 500 ? 'HTTP_UNKNOWN' : response.status === 401 ? 'HTTP_UNAUTHORIZED' : response.status === 403 ? 'HTTP_FORBIDDEN' : response.status === 429 ? 'HTTP_RATE_LIMITED' : 'HTTP_REJECTED';
      throw new CoreError(code, 'transport', response.status >= 500 ? 'unknown' : 'rejected',
        { httpStatus: response.status, safeProviderCode });
    }
    const bytes = await readBoundedBody(response, maxResponseBytes);
    const contentType = response.headers?.get?.('content-type') ?? '';
    if (!/^application\/json(?:\s*;|\s*$)/i.test(contentType) && !(liara && !contentType && typeof response.json === 'function')) {
      throw new CoreError('INVALID_CONTENT_TYPE', 'protocol', 'unknown', { httpStatus: response.status });
    }
    return { status: response.status, contentType: 'application_json', bytes, latencyMs: Math.max(0, Math.round(performance.now() - started)) };
  } catch (error) {
    if (error instanceof CoreError) throw error;
    throw new CoreError(controller.signal.aborted ? 'TIMEOUT' : 'NETWORK_ERROR', 'protocol', 'unknown');
  } finally { clearTimeout(timeout); }
}

/** GET-only Liara API operation set; paths and query keys are allowlisted. */
export async function requestLiaraReadOnly({ fetchImpl, token, teamId, operation, projectName, params = {}, timeoutMs = 8000, maxResponseBytes = 1048576 }) {
  if (typeof token !== 'string' || !token.trim() || (teamId !== undefined && !/^[A-Za-z0-9_-]{1,100}$/.test(teamId)) ||
      !/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/.test(projectName ?? '') || !['project', 'logs', 'releases', 'releaseLogs'].includes(operation)) {
    throw new CoreError('INVALID_REQUEST', 'config', 'not_sent');
  }
  const suffix = { project: '', logs: '/logs', releases: '/releases', releaseLogs: '/logs' }[operation];
  const version = operation === 'releaseLogs' ? 'v2' : 'v1';
  const query = { ...(teamId === undefined ? {} : { teamID: teamId }), ...Object.fromEntries(Object.entries(params).map(([key, value]) => [key, String(value)])) };
  try {
    const response = await requestBounded({ fetchImpl, endpoint: { profileId: 'liara_readonly',
      path: `/${version}/projects/${encodeURIComponent(projectName)}${suffix}`, method: 'GET', query, captureErrorCode: true },
      requestId: `liara-${Date.now()}`, headers: { authorization: `Bearer ${token}`, accept: 'application/json' }, body: null,
      timeoutMs, maxResponseBytes });
    return { status: 'AVAILABLE', httpStatus: response.status, bytes: response.bytes };
  } catch (error) {
    if (!(error instanceof CoreError)) return { status: 'UNKNOWN', httpStatus: null };
    if (error.processingState === 'unknown' && error.httpStatus === null) return { status: 'UNKNOWN', httpStatus: null };
    if (error.code === 'RESPONSE_TOO_LARGE' || error.code === 'INVALID_CONTENT_TYPE' || error.code === 'INVALID_PROVIDER_RESPONSE') return { status: 'UNKNOWN', httpStatus: error.httpStatus };
    if (error.code === 'HTTP_UNKNOWN') return { status: 'UNKNOWN', httpStatus: error.httpStatus };
    return { status: 'UNAVAILABLE', httpStatus: error.httpStatus, ...(error.safeProviderCode ? { errorCode: error.safeProviderCode } : {}) };
  }
}
