const SAFE_FIELDS = new Set(['appId', 'environment', 'profileId', 'profileRevision', 'contractVersion', 'requestId',
  'attempt', 'provider', 'requestedModel', 'returnedModel', 'state', 'httpStatus', 'code', 'phase', 'latencyMs',
  'responseBytes', 'mimeCategory', 'bodyFormatCategory', 'inputTokens', 'outputTokens', 'totalTokens']);
const SECRET_TEXT = /(bearer\s+|api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret)/i;

export function safeEvent(event) {
  const output = {};
  for (const [key, value] of Object.entries(event ?? {})) {
    if (!SAFE_FIELDS.has(key) || SECRET_TEXT.test(key) || value === null) continue;
    if (typeof value === 'string') {
      if (value.length > 160 || SECRET_TEXT.test(value) || /[\r\n]/.test(value)) continue;
      output[key] = value;
    } else if (typeof value === 'number' && Number.isFinite(value) && value >= 0) output[key] = value;
  }
  return Object.freeze(output);
}
