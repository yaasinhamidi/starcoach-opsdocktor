const ID = /^[A-Za-z0-9._:/-]{1,160}$/;

/**
 * Bind reservations to stable app and credential identities. The caller supplies
 * its app-owned SQLite connection; this module never opens a database itself.
 */
export function createBudgetLedger(db, { clock = Date.now } = {}) {
  if (!db || typeof db.exec !== 'function' || typeof db.prepare !== 'function') throw new TypeError('SQLite-compatible database required');
  if (db.isTransaction) throw new TypeError('budget ledger requires a dedicated connection with no active transaction');
  db.exec(`CREATE TABLE IF NOT EXISTS starcoach_llm_reservations (
    request_id TEXT PRIMARY KEY, app_budget_id TEXT NOT NULL, credential_budget_id TEXT NOT NULL,
    created_at_ms INTEGER NOT NULL, state TEXT NOT NULL CHECK(state IN ('pending','unknown','completed','rejected')),
    reserved_cost_usd TEXT
  ); CREATE INDEX IF NOT EXISTS starcoach_llm_reservations_app_time ON starcoach_llm_reservations(app_budget_id, created_at_ms);
  CREATE INDEX IF NOT EXISTS starcoach_llm_reservations_credential_time ON starcoach_llm_reservations(credential_budget_id, created_at_ms);`);
  const countAttemptSql = column => `SELECT COUNT(*) AS attempts FROM starcoach_llm_reservations WHERE ${column} = ? AND created_at_ms >= ?`;
  const countActiveSql = column => `SELECT COUNT(*) AS active FROM starcoach_llm_reservations WHERE ${column} = ? AND state IN ('pending','unknown')`;
  const countAppAttempts = db.prepare(countAttemptSql('app_budget_id'));
  const countCredentialAttempts = db.prepare(countAttemptSql('credential_budget_id'));
  const countAppActive = db.prepare(countActiveSql('app_budget_id'));
  const countCredentialActive = db.prepare(countActiveSql('credential_budget_id'));
  const insert = db.prepare(`INSERT INTO starcoach_llm_reservations
    (request_id, app_budget_id, credential_budget_id, created_at_ms, state, reserved_cost_usd)
    VALUES (?, ?, ?, ?, 'pending', ?)`);
  return Object.freeze({
    reserve({ requestId, appBudgetId, credentialBudgetId, windowMs, maxAttempts, maxConcurrent, reservedCostUsd = null }) {
      if (![requestId, appBudgetId, credentialBudgetId].every(value => typeof value === 'string' && ID.test(value)) ||
          !Number.isSafeInteger(windowMs) || windowMs < 1000 || windowMs > 86400000 || !Number.isSafeInteger(maxAttempts) || maxAttempts < 1 || maxAttempts > 1000 ||
          !Number.isSafeInteger(maxConcurrent) || maxConcurrent < 1 || maxConcurrent > 100 ||
          (reservedCostUsd !== null && (typeof reservedCostUsd !== 'string' || !/^(0|[1-9]\d*)(\.\d{1,8})?$/.test(reservedCostUsd)))) {
        return { ok: false, code: 'BUDGET_UNAVAILABLE' };
      }
      const now = clock();
      if (!Number.isSafeInteger(now) || now < 0) return { ok: false, code: 'BUDGET_UNAVAILABLE' };
      let transactionStarted = false;
      try {
        db.exec('BEGIN IMMEDIATE');
        transactionStarted = true;
        const exists = db.prepare('SELECT 1 FROM starcoach_llm_reservations WHERE request_id = ?').get(requestId);
        const appAttempts = countAppAttempts.get(appBudgetId, now - windowMs).attempts;
        const credentialAttempts = countCredentialAttempts.get(credentialBudgetId, now - windowMs).attempts;
        const appActive = countAppActive.get(appBudgetId).active;
        const credentialActive = countCredentialActive.get(credentialBudgetId).active;
        if (exists || appAttempts >= maxAttempts || credentialAttempts >= maxAttempts || appActive >= maxConcurrent || credentialActive >= maxConcurrent) {
          db.exec('ROLLBACK');
          transactionStarted = false;
          return { ok: false, code: exists ? 'BUDGET_UNAVAILABLE' : 'BUDGET_EXCEEDED' };
        }
        insert.run(requestId, appBudgetId, credentialBudgetId, now, reservedCostUsd);
        db.exec('COMMIT');
        transactionStarted = false;
        return { ok: true, requestId, reservedCostUsd };
      } catch {
        if (transactionStarted) try { db.exec('ROLLBACK'); } catch { /* fail closed */ }
        return { ok: false, code: 'BUDGET_UNAVAILABLE' };
      }
    },
    settle(requestId, state, { reconcile = false } = {}) {
      if (!ID.test(requestId) || !['unknown', 'completed', 'rejected'].includes(state)) return false;
      try {
        const result = db.prepare(`UPDATE starcoach_llm_reservations SET state = ? WHERE request_id = ? AND (state = 'pending' OR (? = 1 AND state = 'unknown'))`).run(state, requestId, reconcile ? 1 : 0);
        return result.changes === 1;
      } catch { return false; }
    },
  });
}
