/** Parse one bounded JSON value and reject duplicate object keys. */
export function parseStrictJson(text, { maxBytes = 1_048_576, maxDepth = 64 } = {}) {
  if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > maxBytes) throw new TypeError('JSON input exceeds its byte limit');
  let index = 0;
  const whitespace = () => { while (index < text.length && /\s/.test(text[index])) index += 1; };
  const string = () => {
    const start = index;
    if (text[index++] !== '"') throw new SyntaxError('expected JSON string');
    while (index < text.length) {
      const char = text[index++];
      if (char === '"') return JSON.parse(text.slice(start, index));
      if (char === '\\') index += 1;
      else if (char.charCodeAt(0) < 0x20) throw new SyntaxError('invalid JSON string');
    }
    throw new SyntaxError('unterminated JSON string');
  };
  const value = (depth) => {
    if (depth > maxDepth) throw new SyntaxError('JSON nesting limit exceeded');
    whitespace();
    const char = text[index];
    if (char === '"') return string();
    if (char === '{') {
      index += 1;
      const result = {};
      const keys = new Set();
      whitespace();
      if (text[index] === '}') { index += 1; return result; }
      while (index < text.length) {
        whitespace();
        const key = string();
        if (keys.has(key)) throw new SyntaxError('duplicate JSON key');
        keys.add(key);
        whitespace();
        if (text[index++] !== ':') throw new SyntaxError('expected colon');
        Object.defineProperty(result, key, { value: value(depth + 1), enumerable: true, configurable: true, writable: true });
        whitespace();
        const delimiter = text[index++];
        if (delimiter === '}') return result;
        if (delimiter !== ',') throw new SyntaxError('expected object delimiter');
      }
      throw new SyntaxError('unterminated JSON object');
    }
    if (char === '[') {
      index += 1;
      const result = [];
      whitespace();
      if (text[index] === ']') { index += 1; return result; }
      while (index < text.length) {
        result.push(value(depth + 1));
        whitespace();
        const delimiter = text[index++];
        if (delimiter === ']') return result;
        if (delimiter !== ',') throw new SyntaxError('expected array delimiter');
      }
      throw new SyntaxError('unterminated JSON array');
    }
    const start = index;
    while (index < text.length && !/[\s,\]}]/.test(text[index])) index += 1;
    if (start === index) throw new SyntaxError('expected JSON value');
    return JSON.parse(text.slice(start, index));
  };
  const result = value(0);
  whitespace();
  if (index !== text.length) throw new SyntaxError('trailing JSON data');
  return result;
}
