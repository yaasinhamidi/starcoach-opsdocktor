const CODES = new Set(['INVALID_REQUEST', 'PROFILE_DISABLED', 'MISSING_CREDENTIAL', 'UNSUPPORTED_CAPABILITY', 'INPUT_TOO_LARGE', 'TIMEOUT', 'NETWORK_ERROR', 'REDIRECT_BLOCKED', 'RESPONSE_TOO_LARGE', 'INVALID_CONTENT_TYPE', 'HTTP_UNAUTHORIZED', 'HTTP_FORBIDDEN', 'HTTP_RATE_LIMITED', 'HTTP_REJECTED', 'HTTP_UNKNOWN', 'COMPLETION_TRUNCATED', 'MODEL_REFUSAL', 'INVALID_PROVIDER_ENVELOPE', 'INVALID_PROVIDER_RESPONSE', 'INVALID_OUTPUT_JSON', 'BUDGET_UNAVAILABLE', 'BUDGET_EXCEEDED']);

export class CoreError extends Error {
  constructor(code, phase, processingState, metadata = {}) {
    super(CODES.has(code) ? code : 'PROVIDER_ERROR');
    this.name = 'CoreError';
    this.code = CODES.has(code) ? code : 'PROVIDER_ERROR';
    this.phase = phase;
    this.processingState = processingState;
    this.httpStatus = Number.isInteger(metadata.httpStatus) ? metadata.httpStatus : null;
    this.responseBytes = Number.isSafeInteger(metadata.responseBytes) && metadata.responseBytes >= 0 ? metadata.responseBytes : 0;
    this.mimeCategory = metadata.mimeCategory === 'application_json' ? metadata.mimeCategory : null;
    this.safeProviderCode = typeof metadata.safeProviderCode === 'string' && /^[A-Za-z0-9_.-]{1,64}$/.test(metadata.safeProviderCode) ? metadata.safeProviderCode : null;
  }
}
