export { CoreError } from './errors.mjs';
export { parseStrictJson } from './json.mjs';
export { ENDPOINT_PROFILES, requestBounded, requestLiaraReadOnly } from './http.mjs';
export { createProviderClient, generateWithFallback } from './providers.mjs';
export { createFakeTransport } from './testing.mjs';
export { validateProfile, profileStatus } from './config.mjs';
export { createEnvironmentSecretResolver, CredentialStore, OAuthSession } from './credentials.mjs';
export { safeEvent } from './safe-events.mjs';
export { createBudgetLedger } from './limits.mjs';

/** Neutral contract validation only; intentionally performs no provider I/O. */
export function validateRequest(request) {
  if (!request || request.contractVersion !== 1 || typeof request.requestId !== 'string' ||
      request.requestId.length < 1 || request.requestId.length > 128) throw new TypeError('invalid contract version or request id');
  if (!Array.isArray(request.messages) || request.messages.length < 1 || request.messages.length > 64 ||
      request.messages.some(({ role, text }) => !['system', 'user', 'assistant'].includes(role) || typeof text !== 'string')) {
    throw new TypeError('invalid messages');
  }
  if (!['text', 'json'].includes(request.output?.kind) || !['off', 'required'].includes(request.output?.nativeMode)) {
    throw new TypeError('invalid output mode');
  }
  const limits = request.limits;
  const bounds = [['timeoutMs', 120000], ['maxInputBytes', 1048576], ['maxResponseBytes', 1048576], ['maxOutputTextBytes', 262144]];
  for (const [key, max] of bounds) if (!Number.isSafeInteger(limits?.[key]) || limits[key] < 1 || limits[key] > max) throw new TypeError(`invalid ${key}`);
  if (limits.maxOutputTokens !== null && (!Number.isSafeInteger(limits.maxOutputTokens) || limits.maxOutputTokens < 1 || limits.maxOutputTokens > 32768)) {
    throw new TypeError('invalid maxOutputTokens');
  }
  return request;
}
