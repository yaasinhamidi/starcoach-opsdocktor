import { CoreError } from './errors.mjs';
import { ENDPOINT_PROFILES, requestBounded } from './http.mjs';
import { parseStrictJson } from './json.mjs';
import { validateProfile } from './config.mjs';

const PROVIDERS = Object.freeze({ openai_api: 'openai_api', openrouter: 'openrouter', boxapi: 'boxapi' });
const FALLBACK_CODES = new Set(['HTTP_UNAUTHORIZED', 'HTTP_FORBIDDEN', 'HTTP_RATE_LIMITED', 'HTTP_REJECTED']);

function validateRequest(request) {
  if (!request || request.contractVersion !== 1 || typeof request.requestId !== 'string' || !/^[A-Za-z0-9._:-]{1,128}$/.test(request.requestId) ||
      !Array.isArray(request.messages) || request.messages.length < 1 || request.messages.length > 64 ||
      request.messages.some(message => !message || !['system', 'user', 'assistant'].includes(message.role) || typeof message.text !== 'string') ||
      !['text', 'json'].includes(request.output?.kind) || !['off', 'required'].includes(request.output?.nativeMode)) {
    throw new CoreError('INVALID_REQUEST', 'preflight', 'not_sent');
  }
  const pairs = [['timeoutMs', 120000], ['maxInputBytes', 1048576], ['maxResponseBytes', 1048576], ['maxOutputTextBytes', 262144]];
  for (const [key, max] of pairs) if (!Number.isSafeInteger(request.limits?.[key]) || request.limits[key] < 1 || request.limits[key] > max) throw new CoreError('INVALID_REQUEST', 'preflight', 'not_sent');
  if (request.limits.maxOutputTokens !== null && (!Number.isSafeInteger(request.limits.maxOutputTokens) || request.limits.maxOutputTokens < 1 || request.limits.maxOutputTokens > 32768)) throw new CoreError('INVALID_REQUEST', 'preflight', 'not_sent');
}

function safeUsage(usage, payload) {
  const count = value => Number.isSafeInteger(value) && value >= 0 ? value : null;
  const cost = value => typeof value === 'number' && Number.isFinite(value) && value >= 0 ? String(value) : null;
  return { inputTokens: count(usage?.prompt_tokens), outputTokens: count(usage?.completion_tokens), totalTokens: count(usage?.total_tokens),
    estimatedCostUsd: null, reportedCostUsd: cost(payload?.cost) ?? cost(usage?.cost), reservedCostUsd: null, pricingRevision: null };
}

export function createProviderClient({ profile, secretResolver, budgetLedger, fetchImpl = globalThis.fetch, clock = () => performance.now() }) {
  validateProfile(profile);
  if (!budgetLedger || typeof budgetLedger.reserve !== 'function' || typeof budgetLedger.settle !== 'function') throw new TypeError('app-owned budget ledger required');
  const endpoint = ENDPOINT_PROFILES[profile.endpointProfileId];
  const provider = PROVIDERS[profile.provider];
  return Object.freeze({
    appBudgetId: profile.appBudgetId,
    profileId: profile.profileId,
    fallbackPolicy: Object.freeze({ ...profile.fallback, allowedErrorCodes: Object.freeze([...profile.fallback.allowedErrorCodes]) }),
    capabilities() {
      return Object.freeze({ protocol: 'chat_completions', text: true,
        jsonObject: endpoint.jsonObject ? 'supported' : 'unsupported', outputTokenParameter: profile.tokenParameter,
        upstreamSseRequired: false, catalogSupported: endpoint.catalog, evidenceRevision: 'starcoach-core-0.5.0', checkedAt: null, tools: false });
    },
    async discoverModels(options) {
      if (profile.enabled !== true) return { ok: false, provider, connectionRef: profile.credentialRef, checkedAt: new Date().toISOString(), expiresAt: null, entries: [], errorCode: 'PROFILE_DISABLED' };
      if (options?.authorized !== true || !Number.isInteger(options.timeoutMs) || options.timeoutMs < 1 || options.timeoutMs > profile.ceilings.timeoutMs ||
          !Number.isInteger(options.maxResponseBytes) || options.maxResponseBytes < 1 || options.maxResponseBytes > profile.ceilings.maxResponseBytes) {
        return { ok: false, provider, connectionRef: profile.credentialRef, checkedAt: new Date().toISOString(), expiresAt: null, entries: [], errorCode: 'INVALID_REQUEST' };
      }
      if (!endpoint.catalog) return { ok: false, provider, connectionRef: profile.credentialRef, checkedAt: new Date().toISOString(), expiresAt: null, entries: [], errorCode: 'UNSUPPORTED_CAPABILITY' };
      try {
        let secret;
        try { secret = await secretResolver.resolve(profile.credentialRef); }
        catch { throw new CoreError('MISSING_CREDENTIAL', 'preflight', 'not_sent'); }
        if (typeof secret !== 'string' || !secret) throw new CoreError('MISSING_CREDENTIAL', 'preflight', 'not_sent');
        const response = await requestBounded({ fetchImpl, endpoint: { profileId: profile.endpointProfileId,
          path: `${endpoint.basePath}/models`, method: 'GET' }, requestId: `catalog-${Date.now()}`,
          headers: { authorization: `Bearer ${secret}`, accept: 'application/json' }, body: null,
          timeoutMs: options.timeoutMs, maxResponseBytes: options.maxResponseBytes });
        const payload = parseStrictJson(response.bytes.toString('utf8'), { maxBytes: options.maxResponseBytes });
        if (!Array.isArray(payload?.data) || payload.data.length > 2000) throw new CoreError('INVALID_PROVIDER_RESPONSE', 'protocol', 'unknown');
        const entries = [];
        const seen = new Set();
        for (const item of payload.data) {
          if (typeof item?.id !== 'string' || !/^[A-Za-z0-9._:/-]{1,120}$/.test(item.id) || item.id.includes(secret) || seen.has(item.id)) continue;
          seen.add(item.id);
          const displayName = typeof item.name === 'string' && item.name.length <= 160 && !item.name.includes(secret) ? item.name : item.id;
          entries.push({ id: item.id, displayName });
        }
        const checkedAt = new Date().toISOString();
        return { ok: true, provider, connectionRef: profile.credentialRef, checkedAt,
          expiresAt: new Date(Date.now() + Math.min(options.cacheTtlMs ?? 300000, 3600000)).toISOString(), entries, errorCode: null };
      } catch (error) {
        return { ok: false, provider, connectionRef: profile.credentialRef, checkedAt: new Date().toISOString(), expiresAt: null,
          entries: [], errorCode: error instanceof CoreError ? error.code : 'NETWORK_ERROR' };
      }
    },
    async generate(request, { reservationId = request?.requestId } = {}) {
      let attempt;
      let reserved = false;
      try {
        validateRequest(request);
        if (profile.enabled !== true) throw new CoreError('PROFILE_DISABLED', 'preflight', 'not_sent');
        if (request.output.nativeMode === 'required' && (request.output.kind !== 'json' || !endpoint.jsonObject)) throw new CoreError('UNSUPPORTED_CAPABILITY', 'preflight', 'not_sent');
        const messages = request.messages.map(({ role, text }) => ({ role, content: text }));
        const inputBytes = Buffer.byteLength(JSON.stringify(messages), 'utf8');
        if (inputBytes > Math.min(request.limits.maxInputBytes, profile.ceilings.maxInputBytes)) throw new CoreError('INPUT_TOO_LARGE', 'preflight', 'not_sent');
        if (!secretResolver || typeof secretResolver.resolve !== 'function') throw new CoreError('MISSING_CREDENTIAL', 'preflight', 'not_sent');
        if (profile.costPolicy?.mode !== 'request_quota_only') throw new CoreError('BUDGET_UNAVAILABLE', 'budget', 'not_sent');
        if (typeof reservationId !== 'string' || !/^[A-Za-z0-9._:-]{1,160}$/.test(reservationId)) throw new CoreError('INVALID_REQUEST', 'preflight', 'not_sent');
        const reservation = budgetLedger.reserve({ requestId: reservationId, appBudgetId: profile.appBudgetId,
          credentialBudgetId: profile.credentialBudgetId, windowMs: profile.requestQuota.windowSeconds * 1000,
          maxAttempts: profile.requestQuota.maxAttempts, maxConcurrent: profile.requestQuota.maxConcurrent });
        if (!reservation?.ok) throw new CoreError(reservation?.code === 'BUDGET_EXCEEDED' ? 'BUDGET_EXCEEDED' : 'BUDGET_UNAVAILABLE', 'budget', 'not_sent');
        reserved = true;
        let secret;
        try { secret = await secretResolver.resolve(profile.credentialRef); }
        catch { throw new CoreError('MISSING_CREDENTIAL', 'preflight', 'not_sent'); }
        if (typeof secret !== 'string' || !secret) throw new CoreError('MISSING_CREDENTIAL', 'preflight', 'not_sent');
        const started = clock();
        const body = { model: profile.model, messages,
          [profile.tokenParameter]: Math.min(request.limits.maxOutputTokens ?? profile.ceilings.maxOutputTokens, profile.ceilings.maxOutputTokens),
          temperature: 0, stream: false,
          ...(request.output.kind === 'json' && request.output.nativeMode === 'required' && endpoint.jsonObject ? { response_format: { type: 'json_object' } } : {}),
          ...(profile.includeUsage && provider === 'openrouter' ? { usage: { include: true } } : {}),
          ...(provider === 'openrouter' ? { provider: { only: [profile.upstreamProviderId], allow_fallbacks: false } } : {}) };
        const response = await requestBounded({ fetchImpl, endpoint: { profileId: profile.endpointProfileId,
          path: `${endpoint.basePath}${endpoint.chatPath}`, method: 'POST', captureErrorCode: true }, requestId: request.requestId,
          headers: { authorization: `Bearer ${secret}`, 'content-type': 'application/json',
            ...(provider === 'openrouter' ? { 'http-referer': 'https://starcoach.local', 'x-title': profile.clientTitle ?? `Starcoach ${profile.appId}` } : {}) },
          body: JSON.stringify(body), timeoutMs: Math.min(request.limits.timeoutMs, profile.ceilings.timeoutMs),
          maxResponseBytes: Math.min(request.limits.maxResponseBytes, profile.ceilings.maxResponseBytes) });
        let payload;
        try { payload = parseStrictJson(response.bytes.toString('utf8'), { maxBytes: Math.min(request.limits.maxResponseBytes, profile.ceilings.maxResponseBytes) }); }
        catch { throw new CoreError('INVALID_PROVIDER_ENVELOPE', 'protocol', 'unknown', { httpStatus: response.status, responseBytes: response.bytes.length, mimeCategory: 'application_json' }); }
        const choices = payload?.choices;
        const choice = Array.isArray(choices) && choices.length === 1 ? choices[0] : null;
        attempt = { provider, requestedModel: profile.model,
          returnedModel: typeof payload?.model === 'string' && /^[A-Za-z0-9._:/-]{1,120}$/.test(payload.model) && !payload.model.includes(secret) ? payload.model : null,
          state: 'unknown', httpStatus: response.status, code: null,
          latencyMs: Math.max(response.latencyMs, Math.round(clock() - started)), responseBytes: response.bytes.length,
          mimeCategory: 'application_json', bodyFormatCategory: 'json', providerRequestId: null, usage: safeUsage(payload?.usage, payload) };
        if (choice?.finish_reason === 'length') throw new CoreError('COMPLETION_TRUNCATED', 'output', 'unknown');
        if (choice?.message?.refusal) throw new CoreError('MODEL_REFUSAL', 'output', 'unknown');
        if (!choice || choice.finish_reason !== 'stop' || !choice.message || choice.message.refusal || typeof choice.message.content !== 'string') throw new CoreError('INVALID_PROVIDER_RESPONSE', 'protocol', 'unknown');
        const text = choice.message.content;
        if (Buffer.byteLength(text, 'utf8') > Math.min(request.limits.maxOutputTextBytes, profile.ceilings.maxOutputTextBytes)) throw new CoreError('INVALID_PROVIDER_RESPONSE', 'output', 'unknown');
        let jsonValue;
        if (request.output.kind === 'json') {
          try { jsonValue = parseStrictJson(text, { maxBytes: Math.min(request.limits.maxOutputTextBytes, profile.ceilings.maxOutputTextBytes) }); }
          catch { throw new CoreError('INVALID_OUTPUT_JSON', 'output', 'unknown'); }
        }
        attempt.state = 'completed';
        budgetLedger.settle(reservationId, 'completed');
        reserved = false;
        return { ok: true, text, ...(request.output.kind === 'json' ? { jsonValue } : {}), attempts: [attempt] };
      } catch (error) {
        const failure = error instanceof CoreError ? error : new CoreError('NETWORK_ERROR', 'transport', 'unknown');
        if (!attempt && failure.processingState !== 'not_sent') attempt = { provider, requestedModel: profile.model,
          returnedModel: null, state: failure.processingState, httpStatus: failure.httpStatus, code: failure.code,
          latencyMs: 0, responseBytes: failure.responseBytes, mimeCategory: failure.mimeCategory,
          bodyFormatCategory: null, providerRequestId: null, usage: safeUsage(null) };
        if (reserved) {
          budgetLedger.settle(reservationId, failure.processingState === 'not_sent' ? 'rejected' :
            failure.processingState === 'rejected' ? 'rejected' : 'unknown');
          reserved = false;
        }
        if (attempt && failure.processingState === 'unknown') attempt.state = 'unknown';
        return { ok: false, error: { code: failure.code, phase: failure.phase, processingState: failure.processingState,
          providerCode: failure.safeProviderCode }, attempts: attempt ? [attempt] : [] };
      }
    },
  });
}

/** One explicit alternate, only for caller-allowlisted pre-send or rejection codes. */
export async function generateWithFallback(primary, alternate, request, policy) {
  const first = await primary.generate(request);
  if (first.ok || policy?.enabled !== true || policy.maxAttempts !== 2 || !alternate ||
      !['not_sent', 'rejected'].includes(first.error.processingState) ||
      !Array.isArray(policy.allowedErrorCodes) || policy.allowedErrorCodes.some(code => !FALLBACK_CODES.has(code)) ||
      !policy.allowedErrorCodes.includes(first.error.code) || primary.fallbackPolicy?.enabled !== true ||
      policy.alternateProfileId !== alternate.profileId || policy.alternateProfileId !== primary.fallbackPolicy.alternateProfileId ||
      policy.maxAttempts !== primary.fallbackPolicy.maxAttempts ||
      JSON.stringify(policy.allowedErrorCodes) !== JSON.stringify(primary.fallbackPolicy.allowedErrorCodes)) return first;
  if (!primary.appBudgetId || primary.appBudgetId !== alternate.appBudgetId) return first;
  const second = await alternate.generate(request, { reservationId: `${request.requestId}-fallback` });
  return { ...second, attempts: [...first.attempts, ...second.attempts] };
}
