import { ENDPOINT_PROFILES } from './http.mjs';

const PROVIDERS = Object.freeze({ openai_api: 'openai_api', openrouter: 'openrouter', boxapi: 'boxapi' });
const SECRET_KEY = /(?:api[_-]?key|access[_-]?token|refresh[_-]?token|secret|password|authorization)/i;
const onlyKeys = (value, keys) => value && typeof value === 'object' && Object.keys(value).every(key => keys.includes(key));

function rejectSecretFields(value, depth = 0) {
  if (depth > 12) throw new TypeError('profile nesting limit exceeded');
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) {
    if (SECRET_KEY.test(key)) throw new TypeError('secret material is not allowed in provider profiles');
    rejectSecretFields(child, depth + 1);
  }
}

export function validateProfile(profile) {
  rejectSecretFields(profile);
  const allowedFields = new Set(['schemaVersion', 'appId', 'environment', 'profileId', 'revision', 'enabled', 'provider', 'endpointProfileId',
    'upstreamProviderId', 'tokenParameter', 'includeUsage', 'clientTitle', 'model', 'credentialRef', 'appBudgetId', 'credentialBudgetId', 'ceilings', 'requestQuota', 'costPolicy', 'fallback']);
  allowedFields.add('includeUsage');
  if (!profile || Object.keys(profile).some(key => !allowedFields.has(key))) throw new TypeError('unknown provider profile field');
  if (!profile || profile.schemaVersion !== 1 || typeof profile.appId !== 'string' || !/^[a-z0-9][a-z0-9._-]{0,63}$/.test(profile.appId) ||
      typeof profile.environment !== 'string' || !/^[a-z0-9][a-z0-9._-]{0,31}$/.test(profile.environment) ||
      typeof profile.profileId !== 'string' || !/^[a-z0-9][a-z0-9._-]{0,63}$/.test(profile.profileId) ||
      !Number.isSafeInteger(profile.revision) || profile.revision < 1 || typeof profile.enabled !== 'boolean' ||
      !PROVIDERS[profile.provider] || !ENDPOINT_PROFILES[profile.endpointProfileId] ||
      typeof profile.model !== 'string' || !/^[A-Za-z0-9._:/-]{1,120}$/.test(profile.model) ||
      typeof profile.credentialRef !== 'string' || !/^(?:env:[A-Z][A-Z0-9_]{0,63}|vault:[a-z0-9._:-]{1,128})$/.test(profile.credentialRef) ||
      !['max_tokens', 'max_completion_tokens'].includes(profile.tokenParameter) ||
      (profile.includeUsage !== undefined && typeof profile.includeUsage !== 'boolean') ||
      (profile.includeUsage === true && profile.provider !== 'openrouter') ||
      (profile.clientTitle !== undefined && (typeof profile.clientTitle !== 'string' || !/^[A-Za-z0-9 ._-]{1,80}$/.test(profile.clientTitle))) ||
      (profile.includeUsage !== undefined && typeof profile.includeUsage !== 'boolean') ||
      (profile.provider === 'openrouter' ? typeof profile.upstreamProviderId !== 'string' || !/^[a-z0-9][a-z0-9-]{0,50}$/.test(profile.upstreamProviderId) : profile.upstreamProviderId != null) ||
      profile.appBudgetId !== `${profile.appId}/${profile.environment}` ||
      profile.credentialBudgetId !== `${profile.appBudgetId}/${profile.credentialRef}`) throw new TypeError('invalid versioned provider profile');
  if (!onlyKeys(profile.ceilings, ['timeoutMs', 'maxInputBytes', 'maxResponseBytes', 'maxOutputTextBytes', 'maxOutputTokens']) ||
      !onlyKeys(profile.requestQuota, ['maxAttempts', 'windowSeconds', 'maxConcurrent']) ||
      !Number.isInteger(profile.requestQuota.maxAttempts) || profile.requestQuota.maxAttempts < 1 || profile.requestQuota.maxAttempts > 1000 ||
      !Number.isInteger(profile.requestQuota.windowSeconds) || profile.requestQuota.windowSeconds < 1 || profile.requestQuota.windowSeconds > 86400 ||
      !Number.isInteger(profile.requestQuota.maxConcurrent) || profile.requestQuota.maxConcurrent < 1 || profile.requestQuota.maxConcurrent > 100) throw new TypeError('invalid request quota');
  if (!onlyKeys(profile.costPolicy, ['mode', 'maxRequestUsd', 'maxWindowUsd', 'windowSeconds', 'pricingRevision']) || !profile.costPolicy || !['request_quota_only', 'reserved_usd'].includes(profile.costPolicy.mode) ||
      profile.costPolicy.mode === 'reserved_usd' && (typeof profile.costPolicy.maxRequestUsd !== 'string' || !/^(0|[1-9]\d*)(\.\d{1,8})?$/.test(profile.costPolicy.maxRequestUsd))) throw new TypeError('invalid cost policy');
  if (!onlyKeys(profile.fallback, ['enabled', 'alternateProfileId', 'allowedErrorCodes', 'maxAttempts']) || !profile.fallback || typeof profile.fallback.enabled !== 'boolean' || ![1, 2].includes(profile.fallback.maxAttempts) ||
      !Array.isArray(profile.fallback.allowedErrorCodes) || profile.fallback.allowedErrorCodes.length > 4 ||
      new Set(profile.fallback.allowedErrorCodes).size !== profile.fallback.allowedErrorCodes.length ||
      profile.fallback.allowedErrorCodes.some(code => !['HTTP_UNAUTHORIZED', 'HTTP_FORBIDDEN', 'HTTP_RATE_LIMITED', 'HTTP_REJECTED'].includes(code)) ||
      (profile.fallback.enabled ? profile.fallback.maxAttempts !== 2 || typeof profile.fallback.alternateProfileId !== 'string' || !/^[a-z0-9][a-z0-9._-]{0,63}$/.test(profile.fallback.alternateProfileId) || profile.fallback.alternateProfileId === profile.profileId : profile.fallback.maxAttempts !== 1 || profile.fallback.alternateProfileId !== null || profile.fallback.allowedErrorCodes.length !== 0)) throw new TypeError('invalid fallback policy');
  if (profile.provider === 'openai_api' && profile.endpointProfileId !== 'openai_api' ||
      profile.provider === 'openrouter' && profile.endpointProfileId !== 'openrouter' ||
      profile.provider === 'boxapi' && !['boxapi_ai_v1', 'boxapi_api_v1'].includes(profile.endpointProfileId)) throw new TypeError('provider and fixed endpoint profile do not match');
  if (!profile.ceilings || !Number.isInteger(profile.ceilings.timeoutMs) || profile.ceilings.timeoutMs < 1 || profile.ceilings.timeoutMs > 120000 ||
      !Number.isInteger(profile.ceilings.maxInputBytes) || profile.ceilings.maxInputBytes < 1 || profile.ceilings.maxInputBytes > 1048576 ||
      !Number.isInteger(profile.ceilings.maxResponseBytes) || profile.ceilings.maxResponseBytes < 1 || profile.ceilings.maxResponseBytes > 1048576 ||
      !Number.isInteger(profile.ceilings.maxOutputTextBytes) || profile.ceilings.maxOutputTextBytes < 1 || profile.ceilings.maxOutputTextBytes > 262144) throw new TypeError('invalid profile ceilings');
  if (profile.ceilings.maxOutputTokens !== null && (!Number.isInteger(profile.ceilings.maxOutputTokens) || profile.ceilings.maxOutputTokens < 1 || profile.ceilings.maxOutputTokens > 32768)) throw new TypeError('invalid output-token ceiling');
  return Object.freeze(structuredClone(profile));
}

export function profileStatus(profile) {
  const valid = validateProfile(profile);
  return Object.freeze({ appId: valid.appId, environment: valid.environment, profileId: valid.profileId,
    revision: valid.revision, enabled: valid.enabled, provider: valid.provider,
    model: valid.model ?? null, connection: valid.enabled ? 'CONFIGURED_UNVERIFIED' : 'DISABLED',
    credentialRefConfigured: typeof valid.credentialRef === 'string', networkChecked: false });
}
