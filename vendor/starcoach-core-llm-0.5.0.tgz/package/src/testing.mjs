/** In-memory fetch substitute. It never opens sockets and fails on exhaustion. */
export function createFakeTransport(responses) {
  const queue = [...responses];
  const requests = [];
  const fetchImpl = async (url, options) => {
    requests.push({ url: String(url), options: { ...options, headers: { ...options.headers } } });
    if (queue.length === 0) throw new Error('fake transport exhausted');
    const next = queue.shift();
    if (next instanceof Error) throw next;
    return new Response(next.body ?? '', { status: next.status ?? 200, headers: next.headers ?? { 'content-type': 'application/json' } });
  };
  return { fetchImpl, requests, remaining: () => queue.length };
}
