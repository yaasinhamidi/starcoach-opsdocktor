/** Resolve an explicitly named server environment variable; never searches profiles. */
export function createEnvironmentSecretResolver(env = process.env) {
  return Object.freeze({
    resolve(reference) {
      if (typeof reference !== 'string' || !/^env:[A-Z][A-Z0-9_]{0,63}$/.test(reference)) return null;
      const value = env[reference.slice(4)];
      return typeof value === 'string' && value.length > 0 ? value : null;
    },
  });
}

/** Optional local store contract; an OS-backed implementation is intentionally separate. */
export class CredentialStore {
  async get(_namespace, _reference) { throw new Error('credential store adapter is not installed'); }
  async put(_namespace, _reference, _secret) { throw new Error('credential store adapter is not installed'); }
  async revoke(_namespace, _reference) { throw new Error('credential store adapter is not installed'); }
  async status(_namespace, _reference) { return { state: 'unavailable' }; }
}

export class OAuthSession {
  async accessToken(_requiredScopes) { throw new Error('OAuth adapter is not installed'); }
  async status() { return { state: 'unavailable', scopes: [] }; }
  async revoke() { return { state: 'unsupported' }; }
}
