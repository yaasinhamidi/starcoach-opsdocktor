export type Message = { role: 'system' | 'user' | 'assistant'; text: string };
export type GenerateRequest = {
  contractVersion: 1; requestId: string; messages: Message[];
  output: { kind: 'text' | 'json'; nativeMode: 'off' | 'required' };
  limits: { timeoutMs: number; maxInputBytes: number; maxResponseBytes: number; maxOutputTextBytes: number; maxOutputTokens: number | null };
};
export type ProcessingState = 'not_sent' | 'rejected' | 'unknown' | 'completed';
export type Usage = {
  inputTokens: number | null; outputTokens: number | null; totalTokens: number | null;
  estimatedCostUsd: string | null; reportedCostUsd: string | null; reservedCostUsd: string | null;
  pricingRevision: string | null;
};
export type Attempt = {
  provider: string; requestedModel: string; returnedModel: string | null; state: ProcessingState;
  httpStatus: number | null; code: string | null; latencyMs: number; responseBytes: number;
  mimeCategory: string | null; bodyFormatCategory: string | null; providerRequestId: string | null; usage: Usage;
};
export type GenerateResult =
  | { ok: true; text: string; jsonValue?: unknown; attempts: Attempt[] }
  | { ok: false; error: { code: string; phase: 'config' | 'preflight' | 'transport' | 'protocol' | 'output' | 'budget'; processingState: ProcessingState; providerCode?: string | null }; attempts: Attempt[] };
export type ModelCapabilities = {
  protocol: 'chat_completions' | 'responses'; text: boolean;
  jsonObject: 'supported' | 'unsupported' | 'unknown'; outputTokenParameter: string | null;
  upstreamSseRequired: boolean; catalogSupported: boolean; evidenceRevision: string;
  checkedAt: string | null; tools: false;
};
export type CatalogEntry = { id: string; displayName: string; capabilities?: ModelCapabilities };
export type CatalogResult = {
  ok: boolean; provider: string; connectionRef: string; checkedAt: string; expiresAt: string | null;
  entries: CatalogEntry[]; errorCode: string | null;
};
export interface LlmClient {
  appBudgetId?: string;
  profileId?: string;
  fallbackPolicy?: ProviderProfile['fallback'];
  generate(request: GenerateRequest, options?: { signal?: AbortSignal; reservationId?: string }): Promise<GenerateResult>;
  capabilities(): ModelCapabilities;
  discoverModels(options: { authorized: true; timeoutMs: number; maxResponseBytes: number; cacheTtlMs?: number }): Promise<CatalogResult>;
}
export interface CatalogProvider {
  discover(options: { authorized: true; timeoutMs: number }): Promise<CatalogResult>;
}
export type ProviderProfile = {
  enabled: boolean; provider: 'openai_api' | 'openrouter' | 'boxapi';
  endpointProfileId: 'openai_api' | 'openrouter' | 'boxapi_ai_v1' | 'boxapi_api_v1';
  schemaVersion: 1; appId: string; environment: string; profileId: string; revision: number;
  tokenParameter: 'max_tokens' | 'max_completion_tokens'; model: string; credentialRef: string;
  upstreamProviderId: string | null; includeUsage?: boolean; clientTitle?: string; appBudgetId: string; credentialBudgetId: string;
  ceilings: Omit<GenerateRequest['limits'], 'maxOutputTokens'> & { maxOutputTokens: number };
  requestQuota: { maxAttempts: number; windowSeconds: number; maxConcurrent: number };
  costPolicy: { mode: 'request_quota_only' | 'reserved_usd'; maxRequestUsd?: string | null; maxWindowUsd?: string | null; windowSeconds?: number; pricingRevision?: string | null };
  fallback: { enabled: boolean; alternateProfileId: string | null; allowedErrorCodes: Array<'HTTP_UNAUTHORIZED' | 'HTTP_FORBIDDEN' | 'HTTP_RATE_LIMITED' | 'HTTP_REJECTED'>; maxAttempts: 1 | 2 };
};
export declare class CoreError extends Error {
  code: string; phase: string; processingState: ProcessingState; httpStatus: number | null;
  responseBytes: number; mimeCategory: string | null; safeProviderCode: string | null;
  constructor(code: string, phase: string, processingState: ProcessingState);
}
export declare function parseStrictJson(text: string, options?: { maxBytes?: number; maxDepth?: number }): unknown;
export declare const ENDPOINT_PROFILES: Readonly<Record<string, Readonly<{ origin: string; basePath: string; chatPath: string; tokenParameter: string; jsonObject: boolean; catalog: boolean }>>>;
export declare function requestBounded(options: { fetchImpl: typeof fetch; endpoint: { profileId: string; path: string }; requestId: string; headers: Record<string, string>; body: string; timeoutMs: number; maxResponseBytes: number }): Promise<{ status: number; contentType: string; bytes: Uint8Array; latencyMs: number }>;
export declare function requestLiaraReadOnly(options: { fetchImpl: typeof fetch; token: string; teamId?: string; operation: 'project' | 'logs' | 'releases' | 'releaseLogs'; projectName: string; params?: Record<string, string | number | boolean>; timeoutMs?: number; maxResponseBytes?: number }): Promise<{ status: 'AVAILABLE' | 'UNAVAILABLE' | 'UNKNOWN'; httpStatus: number | null; bytes?: Uint8Array; errorCode?: string }>;
export declare function createProviderClient(options: { profile: ProviderProfile; secretResolver: { resolve(ref: string): Promise<string | null> | string | null }; budgetLedger: { reserve(args: unknown): { ok: boolean; code?: string }; settle(id: string, state: 'unknown' | 'completed' | 'rejected'): boolean }; fetchImpl?: typeof fetch; clock?: () => number }): LlmClient;
export declare function generateWithFallback(primary: LlmClient, alternate: LlmClient | null, request: GenerateRequest,
  policy: { enabled: boolean; maxAttempts: 1 | 2; allowedErrorCodes: string[] }): Promise<GenerateResult>;
export declare function createFakeTransport(responses: Array<{ status?: number; headers?: Record<string, string>; body?: string } | Error>): {
  fetchImpl: typeof fetch; requests: Array<{ url: string; options: RequestInit }>; remaining(): number;
};
export declare function validateProfile(profile: ProviderProfile): Readonly<ProviderProfile>;
export declare function profileStatus(profile: ProviderProfile): Readonly<Record<string, unknown>>;
export declare function createEnvironmentSecretResolver(env?: Record<string, string | undefined>): { resolve(reference: string): string | null };
export declare class CredentialStore { get(namespace: string, reference: string): Promise<string>; put(namespace: string, reference: string, secret: string): Promise<void>; revoke(namespace: string, reference: string): Promise<void>; status(namespace: string, reference: string): Promise<{ state: string }> }
export declare class OAuthSession { accessToken(requiredScopes: string[]): Promise<string>; status(): Promise<{ state: string; scopes: string[] }>; revoke(): Promise<{ state: string }> }
export declare function safeEvent(event: Record<string, unknown>): Readonly<Record<string, string | number>>;
export declare function createBudgetLedger(db: { exec(sql: string): void; prepare(sql: string): { get(...args: unknown[]): any; run(...args: unknown[]): { changes: number } } }, options?: { clock?: () => number }): {
  reserve(args: { requestId: string; appBudgetId: string; credentialBudgetId: string; windowMs: number; maxAttempts: number; maxConcurrent: number; reservedCostUsd?: string | null }): { ok: boolean; code?: string; requestId?: string; reservedCostUsd?: string | null };
  settle(requestId: string, state: 'unknown' | 'completed' | 'rejected', options?: { reconcile?: boolean }): boolean;
};
export declare function validateRequest(request: GenerateRequest): GenerateRequest;
