import test from 'node:test';
import assert from 'node:assert/strict';
import { createBudgetLedger, createFakeTransport, createProviderClient, generateWithFallback, parseStrictJson } from '../src/index.mjs';
import { DatabaseSync } from 'node:sqlite';
import { readFile } from 'node:fs/promises';
import { requestBounded, requestLiaraReadOnly, safeEvent, validateProfile } from '../src/index.mjs';

const request = { contractVersion: 1, requestId: 'test-1', messages: [{ role: 'user', text: 'hello' }],
  output: { kind: 'json', nativeMode: 'required' },
  limits: { timeoutMs: 1000, maxInputBytes: 100, maxResponseBytes: 1000, maxOutputTextBytes: 200, maxOutputTokens: 64 } };
const profile = { schemaVersion: 1, appId: 'test-app', environment: 'test', profileId: 'test-profile', revision: 1,
  enabled: true, provider: 'openai_api', endpointProfileId: 'openai_api', tokenParameter: 'max_completion_tokens', model: 'test-model', credentialRef: 'env:TEST_KEY',
  upstreamProviderId: null,
  appBudgetId: 'test-app/test', credentialBudgetId: 'test-app/test/env:TEST_KEY', ceilings: { timeoutMs: 1000, maxInputBytes: 100,
    maxResponseBytes: 1000, maxOutputTextBytes: 200, maxOutputTokens: 64 },
  requestQuota: { maxAttempts: 2, windowSeconds: 60, maxConcurrent: 1 }, costPolicy: { mode: 'request_quota_only' },
  fallback: { enabled: false, alternateProfileId: null, allowedErrorCodes: [], maxAttempts: 1 } };
const budgetLedger = { reserve: () => ({ ok: true }), settle: () => true };

test('strict JSON rejects duplicate keys, trailing data, and excess depth', () => {
  assert.throws(() => parseStrictJson('{"x":1,"x":2}'), /duplicate/);
  assert.throws(() => parseStrictJson('{} false'), /trailing/);
  assert.throws(() => parseStrictJson('[[[0]]]', { maxDepth: 1 }), /nesting/);
});

test('both runtimes can validate the shared profile vector; secret-bearing vector is rejected', async () => {
  const profilePath = new URL('../../../contracts/v1/vectors/valid-profile.json', import.meta.url);
  const invalidProfilePath = new URL('../../../contracts/v1/vectors/invalid-profile-with-secret.json', import.meta.url);
  const valid = JSON.parse(await readFile(profilePath, 'utf8'));
  assert.doesNotThrow(() => validateProfile(valid));
  const invalid = JSON.parse(await readFile(invalidProfilePath, 'utf8'));
  assert.throws(() => validateProfile(invalid), /secret|unknown/i);
});

test('OpenAI profile posts once, caps body and returns structured output without secret leakage', async () => {
  const fake = createFakeTransport([{ body: JSON.stringify({ model: 'test-model', choices: [{ finish_reason: 'stop', message: { content: '{"answer":"ok"}' } }], usage: { prompt_tokens: 3, completion_tokens: 2 }, cost: 0.00002 }) }]);
  const client = createProviderClient({ profile, secretResolver: { resolve: () => 'never-echo-key' }, budgetLedger, fetchImpl: fake.fetchImpl });
  const result = await client.generate(request);
  assert.equal(result.ok, true);
  assert.deepEqual(result.jsonValue, { answer: 'ok' });
  assert.equal(fake.requests.length, 1);
  assert.equal(fake.requests[0].url, 'https://api.openai.com/v1/chat/completions');
  assert.equal(JSON.parse(fake.requests[0].options.body).max_completion_tokens, 64);
  assert.equal(result.attempts[0].usage.reportedCostUsd, '0.00002');
  assert.equal(JSON.stringify(result).includes('never-echo-key'), false);
});

test('wrong MIME becomes ambiguous and cannot trigger configured fallback', async () => {
  const fake = createFakeTransport([{ body: '<html>bad</html>', headers: { 'content-type': 'text/html' } }]);
  const primary = createProviderClient({ profile, secretResolver: { resolve: () => 'key' }, budgetLedger, fetchImpl: fake.fetchImpl });
  const second = createFakeTransport([{ body: '{}' }]);
  const alternate = createProviderClient({ profile: { ...profile, endpointProfileId: 'openrouter', provider: 'openrouter', upstreamProviderId: 'test-provider' },
    secretResolver: { resolve: () => 'other' }, budgetLedger, fetchImpl: second.fetchImpl });
  const result = await generateWithFallback(primary, alternate, request,
    { enabled: true, maxAttempts: 2, allowedErrorCodes: ['INVALID_CONTENT_TYPE'] });
  assert.equal(result.ok, false);
  assert.equal(result.error.code, 'INVALID_CONTENT_TYPE');
  assert.equal(result.error.processingState, 'unknown');
  assert.equal(fake.requests.length, 1);
  assert.equal(second.requests.length, 0);
});

test('explicit definitive-rejection fallback reserves a second attempt in the same app budget', async () => {
  const db = new DatabaseSync(':memory:');
  const ledger = createBudgetLedger(db);
  const firstTransport = createFakeTransport([{ status: 401, body: '{"error":{"code":"unauthorized"}}' }]);
  const secondTransport = createFakeTransport([{ body: JSON.stringify({ choices: [{ finish_reason: 'stop', message: { content: '{"answer":"alternate"}' } }] }) }]);
  const primaryProfile = { ...profile, fallback: { enabled: true, alternateProfileId: 'alt-profile', allowedErrorCodes: ['HTTP_UNAUTHORIZED'], maxAttempts: 2 } };
  const primary = createProviderClient({ profile: primaryProfile, secretResolver: { resolve: () => 'primary-key' }, budgetLedger: ledger, fetchImpl: firstTransport.fetchImpl });
  const alternateProfile = { ...profile, profileId: 'alt-profile', provider: 'openrouter', endpointProfileId: 'openrouter', upstreamProviderId: 'openai',
    credentialRef: 'env:ALT_KEY', credentialBudgetId: `${profile.appBudgetId}/env:ALT_KEY`, includeUsage: true };
  const alternate = createProviderClient({ profile: alternateProfile, secretResolver: { resolve: () => 'alternate-key' }, budgetLedger: ledger, fetchImpl: secondTransport.fetchImpl });
  const result = await generateWithFallback(primary, alternate, { ...request, requestId: 'fallback-1' },
    { enabled: true, alternateProfileId: 'alt-profile', maxAttempts: 2, allowedErrorCodes: ['HTTP_UNAUTHORIZED'] });
  assert.equal(result.ok, true);
  assert.deepEqual(result.jsonValue, { answer: 'alternate' });
  assert.equal(result.attempts.length, 2);
  assert.equal(result.attempts[0].state, 'rejected');
  assert.equal(result.attempts[1].state, 'completed');
  assert.deepEqual(JSON.parse(secondTransport.requests[0].options.body).provider, { only: ['openai'], allow_fallbacks: false });
  assert.deepEqual(JSON.parse(secondTransport.requests[0].options.body).usage, { include: true });
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM starcoach_llm_reservations').get().n, 2);
  db.close();
});

test('BoxAPI endpoint profile must be explicit and profile mismatch is rejected before send', async () => {
  const fake = createFakeTransport([{ body: JSON.stringify({ choices: [{ finish_reason: 'stop', message: { content: 'ok' } }] }) }]);
  const client = createProviderClient({ profile: { ...profile, provider: 'boxapi', endpointProfileId: 'boxapi_ai_v1', tokenParameter: 'max_tokens' },
    secretResolver: { resolve: () => 'key' }, budgetLedger, fetchImpl: fake.fetchImpl });
  const result = await client.generate({ ...request, output: { kind: 'text', nativeMode: 'off' } });
  assert.equal(result.ok, true);
  assert.equal(fake.requests[0].url, 'https://ai.boxapi.ir/ai/v1/chat/completions');
  assert.throws(() => createProviderClient({ profile: { ...profile, provider: 'boxapi', endpointProfileId: 'openai_api' }, secretResolver: {} }));
});

test('SQLite ledger binds app-wide and credential quotas; unknown attempts remain active', () => {
  const db = new DatabaseSync(':memory:');
  let now = 10000;
  const ledger = createBudgetLedger(db, { clock: () => now });
  const base = { appBudgetId: profile.appBudgetId, credentialBudgetId: profile.credentialBudgetId,
    windowMs: 10000, maxAttempts: 3, maxConcurrent: 1 };
  assert.equal(ledger.reserve({ ...base, requestId: 'req-1' }).ok, true);
  assert.equal(ledger.reserve({ ...base, requestId: 'req-2' }).code, 'BUDGET_EXCEEDED');
  assert.equal(ledger.settle('req-1', 'unknown'), true);
  assert.equal(ledger.reserve({ ...base, requestId: 'req-3' }).code, 'BUDGET_EXCEEDED');
  now += 10001;
  assert.equal(ledger.reserve({ ...base, requestId: 'req-still-unknown' }).code, 'BUDGET_EXCEEDED');
  assert.equal(ledger.settle('req-1', 'completed'), false);
  assert.equal(ledger.settle('req-1', 'completed', { reconcile: true }), true);
  assert.equal(ledger.reserve({ ...base, requestId: 'req-4' }).ok, true);
  db.close();
});

test('model catalog is explicit, bounded, and available only on supported provider profiles', async () => {
  const fake = createFakeTransport([{ body: JSON.stringify({ data: [{ id: 'model-a', name: 'Model A' }, { id: 'bad key model' }] }) }]);
  const client = createProviderClient({ profile, secretResolver: { resolve: () => 'catalog-secret' }, budgetLedger, fetchImpl: fake.fetchImpl });
  const denied = await client.discoverModels({ authorized: false, timeoutMs: 500, maxResponseBytes: 500 });
  assert.equal(denied.errorCode, 'INVALID_REQUEST');
  assert.equal(fake.requests.length, 0);
  const result = await client.discoverModels({ authorized: true, timeoutMs: 500, maxResponseBytes: 500 });
  assert.equal(result.ok, true);
  assert.deepEqual(result.entries, [{ id: 'model-a', displayName: 'Model A' }]);
  assert.equal(fake.requests[0].options.method, 'GET');
  assert.equal(fake.requests[0].url, 'https://api.openai.com/v1/models');
});

test('HTTP transport enforces body bounds and fixed host/path with no redirect following', async () => {
  const large = createFakeTransport([{ body: 'x'.repeat(20), headers: { 'content-type': 'application/json' } }]);
  await assert.rejects(() => requestBounded({ fetchImpl: large.fetchImpl,
    endpoint: { profileId: 'openai_api', path: '/v1/chat/completions', method: 'POST' }, requestId: 'bound-1',
    headers: { authorization: 'Bearer secret', 'content-type': 'application/json' }, body: '{}', timeoutMs: 100, maxResponseBytes: 10 }),
  error => error.code === 'RESPONSE_TOO_LARGE' && !JSON.stringify(error).includes('x'.repeat(20)));
  await assert.rejects(() => requestBounded({ fetchImpl: large.fetchImpl,
    endpoint: { profileId: 'openai_api', path: '/v1/../../other', method: 'POST' }, requestId: 'bound-2',
    headers: { authorization: 'Bearer secret' }, body: '{}', timeoutMs: 100, maxResponseBytes: 10 }), error => error.code === 'INVALID_REQUEST');
  assert.equal(large.requests.length, 1);
});

test('safe diagnostic projection excludes payloads, credentials and unknown fields', () => {
  assert.deepEqual(safeEvent({ requestId: 'r1', provider: 'openai_api', code: 'HTTP_REJECTED', prompt: 'private text',
    apiKey: 'secret', responseBytes: 12, bodyFormatCategory: 'json' }),
  { requestId: 'r1', provider: 'openai_api', code: 'HTTP_REJECTED', responseBytes: 12, bodyFormatCategory: 'json' });
  assert.throws(() => validateProfile({ ...profile, apiKey: 'never store this' }), /secret/);
});

test('Liara shared transport is GET-only, fixed-origin, bounded and error-body sanitized', async () => {
  const calls = [];
  const fetchImpl = async (url, options) => {
    calls.push({ url, options });
    return new Response(JSON.stringify({ error: { code: 'ACCESS_DENIED', message: 'Bearer never-show-this private@example.test' } }),
      { status: 403, headers: { 'content-type': 'application/json' } });
  };
  const denied = await requestLiaraReadOnly({ fetchImpl, token: 'local-test-token', teamId: 'team-42', operation: 'project', projectName: 'demo-app' });
  assert.deepEqual(denied, { status: 'UNAVAILABLE', httpStatus: 403, errorCode: 'ACCESS_DENIED' });
  assert.equal(calls[0].url, 'https://api.liara.ir/v1/projects/demo-app?teamID=team-42');
  assert.equal(calls[0].options.method, 'GET');
  assert.equal(calls[0].options.redirect, 'error');
  assert.equal(JSON.stringify(denied).includes('never-show-this'), false);
  await assert.rejects(() => requestLiaraReadOnly({ fetchImpl, token: 'token', operation: 'project', projectName: '../other' }),
    error => error.code === 'INVALID_REQUEST');
  assert.equal(calls.length, 1);
});

test('provider failures expose allowlisted status and provider codes without raw response data', async () => {
  const fake = createFakeTransport([{ status: 403, body: JSON.stringify({ error: { code: 'invalid_api_key', message: 'private person@example.test Bearer never-echo-key' } }) }]);
  const client = createProviderClient({ profile, secretResolver: { resolve: () => 'never-echo-key' }, budgetLedger, fetchImpl: fake.fetchImpl });
  const result = await client.generate(request);
  assert.equal(result.ok, false);
  assert.equal(result.error.code, 'HTTP_FORBIDDEN');
  assert.equal(result.error.providerCode, 'invalid_api_key');
  assert.equal(result.attempts[0].httpStatus, 403);
  assert.equal(JSON.stringify(result).includes('person@example.test'), false);
  assert.equal(JSON.stringify(result).includes('never-echo-key'), false);
});
