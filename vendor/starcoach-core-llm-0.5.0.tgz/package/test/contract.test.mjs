import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { validateRequest } from '../src/index.mjs';

const vectorPath = fileURLToPath(new URL('../../../contracts/v1/vectors/valid-request.json', import.meta.url));
const invalidVectorPath = fileURLToPath(new URL('../../../contracts/v1/vectors/invalid-request.json', import.meta.url));
test('accepts shared contract v1 vector', async () => {
  const vector = JSON.parse(await readFile(vectorPath, 'utf8'));
  assert.doesNotThrow(() => validateRequest(vector));
});
test('rejects out-of-range limits', () => {
  return readFile(invalidVectorPath, 'utf8').then((text) => assert.throws(() => validateRequest(JSON.parse(text))));
});
